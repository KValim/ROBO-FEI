Run in the Terminal:

python controlRobot.py

Dependences

sudo apt-get install libqt4-opengl

sudo apt-get install python-qt4-gl
