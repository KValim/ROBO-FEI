from time import time,ctime
import numpy as np

print('Today is', ctime(time()))
argv = [1,2,3]

print(argv)
