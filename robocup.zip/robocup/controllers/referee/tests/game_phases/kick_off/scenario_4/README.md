# Kick-off - scenario 4

## What is tested

If a robot who has kick off scores directly from the kick-off, goal is not
attributed and game goes on with a goal kick.

## Setup

- Team BLUE has Kick-off
- Only one robot is used

## Description

1. BLUE 2 kicks the ball straight to the goal after PLAYING
2. Goal is not valid, game continues with goal kick for red
