# Kick-off - scenario 5

## What is tested

If a robot who has not kick off waits 10 seconds to enter the center circle
and then shoots directly to the opponent goal, it is considered as valid and a
goal is scored.

## Setup

- Team RED has Kick-off
- Only one robot is used

## Description

1. BLUE 2 waits 10 seconds after PLAYING.
2. BLUE 2 moves to the ball and kicks it straight to the opponent goal.
3. Goal is awarded to blue.
