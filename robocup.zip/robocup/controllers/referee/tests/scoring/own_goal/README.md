# Scoring own goal

## What is tested

A robot from team RED scores a goal in its own goal, then a goal is scored for team BLUE

## Setup

- One robot from each team are used

## Description

1. RED 1 touches the ball after PLAYING near its own goal
3. RED 1 kicks the ball in its own goal
4. A goal is scored for team BLUE
