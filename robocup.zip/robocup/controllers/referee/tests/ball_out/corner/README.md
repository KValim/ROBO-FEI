# Ball-out - corner

## What is tested

- When ball fully crosses the goal line, last touched by a robot of the
  defending team, a corner kick is awarded to the attacking team.
- For the corner kick, the ball is placed at the appropriate location

## Setup

- Team RED has Kick-off and is on left side
- One robot from each team are used

## Description

1. RED 1 touches the ball after PLAYING, then the ball moves outside the field from its own goal line.
2. The ball is replaced on the corner of the touch line and goal line on side the ball left the field.
